// A thin wrapper over @typespec/http-client-csharp: selects our .NET plugin (dist/generator) and owns the consumer
// options. Mirrors @azure-typespec/http-client-csharp (docs/reference/azure-http-client-csharp.emitter.ts).
import {
  createTypeSpecLibrary,
  getNamespaceFullName,
  isNumeric,
  listServices,
  navigateProgram,
  navigateTypesInNamespace,
} from "@typespec/compiler";
import { getAuthentication, getAuthenticationForOperation } from "@typespec/http";
import { emitCodeModel } from "@typespec/http-client-csharp";
import { dirname, isAbsolute, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  diagnostics,
  fullName,
  isAnonymous,
  libraryName,
  listPermissions,
  listTypedIds,
  permissionScalarOf,
  reportDiagnostic,
  requiredPermissionsOf,
} from "./lib/lib.js";

/** MEF export name of the .NET plugin (AspNetCoreServerGenerator in src/). */
const generatorName = "AspNetCoreServerGenerator";

/** Where `npm run build` publishes the plugin. Absolute: the parent resolves relative plugin paths against the output dir. */
const pluginDirectory = fileURLToPath(new URL("../../dist/generator/", import.meta.url));

/**
 * Our decorators reach the .NET generator as InputOperation.Decorators only when listed here (TCGC filters by regex).
 * Named rather than matched: TCGC names every argument after the parameter at its position, which a rest parameter such
 * as @requiresPermission's lacks past the first argument, and throws.
 */
const decoratorPattern = "^SpatialFocus\\.Http\\.@(httpQuery|typedId)$";

/** What the authorization pass attaches to a code-model operation; Spec/Authorization.cs reads it. */
const authorizationDecorator = "SpatialFocus.Http.@authorization";

/** TypeSpec's constraint decorators, listed only with validation on; Spec/Constraints.cs reads them. */
const constraintPattern =
  "^TypeSpec\\.@(minLength|maxLength|pattern|minValue|maxValue|minValueExclusive|maxValueExclusive|minItems|maxItems)$";

/** The bounds that also take dates and durations, which the generated validators do not check. */
const valueBounds = ["@minValue", "@maxValue", "@minValueExclusive", "@maxValueExclusive"];

/**
 * Options a consumer may set in tspconfig.yaml; the compiler rejects anything not listed here. The parent's own options
 * (generator-name, plugins, ...) are set below.
 * @type {import("@typespec/compiler").JSONSchemaType<SlimEmitterOptions>}
 */
const optionsSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    "contracts-namespace": {
      type: "string",
      nullable: true,
      description: "C# namespace of the wire-contract records and enums (the Shared project). Default: <service namespace>.Shared",
    },
    "api-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the endpoints, request records and result unions (the Api project). With {interface} in it, every interface gets a namespace and a folder of its own (Contoso.Features.{interface} puts Widgets into Contoso.Features.Widgets and Widgets/); the status case records all interfaces share use the namespace without the placeholder. Default: <service namespace>.Api",
    },
    "client-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the typed HTTP clients (compiled into the consumer). With {interface} in it, every client and its result unions get a namespace and a folder of their own; ApiClientSupport, the {Status}Problem cases and Success use the namespace without the placeholder. Default: <service namespace>.Client",
    },
    "output-type": {
      type: "string",
      enum: ["contracts", "api", "client", "primitives", "all"],
      nullable: true,
      description:
        "Which output kind to write: contracts, api, client, primitives, or all (default: contracts, api and client). A single kind is written flat into generated-dir, the way one consumer project generates its own slice. primitives writes the Vogen value object of every @typedId scalar of the program into the scalar's own namespace, for the one project every service shares.",
    },
    "generated-dir": {
      type: "string",
      nullable: true,
      description: "Where the generated C# files go. Default: src/Generated below emitter-output-dir. Relative paths resolve against the tspconfig.yaml.",
    },
    validation: {
      type: "string",
      enum: ["none", "fluentvalidation"],
      nullable: true,
      description:
        "Validators from TypeSpec's constraint decorators (@minLength, @pattern, @minValue, ...): none (default) or fluentvalidation. The contracts output gets a FluentValidation validator per input model, the api output one per request and an endpoint filter that answers an invalid request with a 400 before the handler runs. The projects compiling that output reference FluentValidation.",
    },
    "save-inputs": {
      type: "boolean",
      nullable: true,
      description: "Keep tspCodeModel.json and Configuration.json next to the output (the generator tests read them).",
    },
    debug: {
      type: "boolean",
      nullable: true,
      description: "Wait for a debugger to attach to the .NET generator process.",
    },
  },
  required: [],
};

/**
 * @typedef {object} SlimEmitterOptions
 * @property {string} [contracts-namespace]
 * @property {string} [api-namespace]
 * @property {string} [client-namespace]
 * @property {"contracts" | "api" | "client" | "primitives" | "all"} [output-type]
 * @property {string} [generated-dir]
 * @property {"none" | "fluentvalidation"} [validation]
 * @property {boolean} [save-inputs]
 * @property {boolean} [debug]
 */

export const $lib = createTypeSpecLibrary({
  name: libraryName,
  diagnostics,
  emitter: { options: optionsSchema },
});

/**
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 */
export async function $onEmit(context) {
  const [, diagnostics] = await emitSlimCodeModel(context);
  context.program.reportDiagnostics(diagnostics);
}

/**
 * Our defaults, then the parent's emitCodeModel. Exposed so a downstream emitter can pass its own updateCodeModel, the
 * hook for re-injecting what TCGC drops (e.g. @error responses).
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 * @param {(model: any, sdkContext: any) => any} [updateCodeModel]
 */
export async function emitSlimCodeModel(context, updateCodeModel) {
  /** @type {Record<string, unknown>} */
  const options = context.options;
  options["generator-name"] = generatorName;
  options["plugins"] = [pluginDirectory];

  // Relative to the tspconfig, not to wherever tsp was started
  const generatedDir = options["generated-dir"];
  if (typeof generatedDir === "string" && !isAbsolute(generatedDir)) {
    const config = context.program.compilerOptions.config;
    options["generated-dir"] = resolve(config ? dirname(config) : context.program.projectRoot, generatedDir);
  }

  // The code model has no scalars, and holds the enums of a service namespace only, so the typed ids and the permission
  // enums travel from the decorator state as options, which the parent passes through to Configuration.json unchanged
  const typedIds = listTypedIds(context.program);
  const permissions = listPermissions(context.program);
  const services = listServices(context.program);
  const serviceNames = services.map((service) => getNamespaceFullName(service.type));

  // Each check reports on its own before the run stops
  const typedIdsOutside = typedIdsOutsideServices(context.program, typedIds, serviceNames);
  const permissionsOutside = permissionsOutsideServices(context.program, permissions, serviceNames);
  const onePermissionType = onePermissionTypePerService(context.program, services);
  const namesFree = permissionsLeaveNamesFree(context.program, permissions);
  if (!typedIdsOutside || !permissionsOutside || !onePermissionType || !namesFree) {
    return [undefined, []];
  }

  options["typed-ids"] = typedIds.map(({ scalar, ...typedId }) => typedId);
  options["permissions"] = permissions.map(({ declaration, ...set }) => set);
  reportUnenforcedScopes(context.program, services);

  // A primitives spec has no @service, and without a root namespace the parent skips generation
  // (https://github.com/microsoft/typespec/issues/10914). TCGC takes the namespace as an override, which names the code
  // model and, with no models in the program, moves nothing
  if (options["output-type"] === "primitives" && services.length === 0) {
    options["namespace"] = typedIds[0]?.namespace ?? "Primitives";
  }

  // No client is emitted, so nothing "references" the models
  options["unreferenced-types-handling"] = "keepAll";
  const validation = options["validation"] === "fluentvalidation";
  if (validation) {
    reportUnsupportedBounds(context.program);
  }

  options["sdk-context-options"] = {
    additionalDecorators: validation ? [decoratorPattern, constraintPattern] : [decoratorPattern],
  };
  return await emitCodeModel(/** @type {any} */ (context), (model, sdkContext) => {
    attachAuthorization(context.program, model, sdkContext);
    if (validation) {
      normalizeConstraints(model);
    }

    return updateCodeModel ? updateCodeModel(model, sdkContext) : model;
  });
}

/**
 * What each operation's resolved @useAuth and permissions come to, as a decorator on its code-model operation: the parent
 * keeps only the service's scheme, and our decorators stay out of TCGC's list. None where no @useAuth resolves.
 * @param {import("@typespec/compiler").Program} program
 * @param {any} model
 * @param {any} sdkContext
 */
function attachAuthorization(program, model, sdkContext) {
  /** @type {Map<string, import("@typespec/compiler").Operation>} */
  const operations = new Map();
  const pending = [...sdkContext.sdkPackage.clients];
  while (pending.length > 0) {
    const client = pending.pop();
    pending.push(...(client.children ?? []));
    for (const method of client.methods ?? []) {
      const operation = method.__raw ?? method.operation?.__raw?.operation;
      if (operation !== undefined) {
        operations.set(method.crossLanguageDefinitionId, operation);
      }
    }
  }

  // A child client may also be listed at the top level, so an operation is decorated once
  const seen = new Set();
  const clients = [...model.clients];
  while (clients.length > 0) {
    const client = clients.pop();
    clients.push(...(client.children ?? []));
    for (const method of client.methods ?? []) {
      const operation = operations.get(method.operation.crossLanguageDefinitionId);
      const access = operation === undefined || seen.has(method.operation) ? undefined : accessOf(program, operation);
      seen.add(method.operation);
      if (access !== undefined) {
        // A new array: TCGC hands the method's decorators to the operation, and they may be shared further
        method.operation.decorators = [
          ...(method.operation.decorators ?? []),
          { name: authorizationDecorator, arguments: access },
        ];
      }
    }
  }
}

/**
 * What an operation requires of its caller: nothing stated without a @useAuth, no user where it lets one without a token
 * through, otherwise a signed-in user and the permissions of the interface and the operation, by their full names.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Operation} operation
 */
function accessOf(program, operation) {
  const authentication = getAuthenticationForOperation(program, operation);
  if (authentication === undefined) {
    return undefined;
  }

  if (isAnonymous(authentication)) {
    return { access: "anonymous" };
  }

  const members = requiredPermissionsOf(program, operation);
  const scalar = members.length > 0 ? permissionScalarOf(program, members[0]) : undefined;
  return scalar === undefined
    ? { access: "authenticated" }
    : {
        access: "authenticated",
        type: fullName(scalar),
        permissions: members.map((member) => `${fullName(member.enum)}.${member.name}`),
      };
}

/**
 * The generated requirement takes one permission type, so a service whose operations require permissions of two
 * scalars is reported and stops the run.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Service[]} services
 */
function onePermissionTypePerService(program, services) {
  let one = true;
  for (const service of services) {
    /** @type {Set<string>} */
    const scalars = new Set();
    navigateTypesInNamespace(service.type, {
      operation(operation) {
        for (const member of requiredPermissionsOf(program, operation)) {
          const scalar = permissionScalarOf(program, member);
          if (scalar !== undefined) {
            scalars.add(fullName(scalar));
          }
        }
      },
    });

    if (scalars.size > 1) {
      const [first, second] = [...scalars];
      reportDiagnostic(program, {
        code: "permissions-of-two-types",
        format: { service: getNamespaceFullName(service.type), first, second },
        target: service.type,
      });
      one = false;
    }
  }

  return one;
}

/**
 * OAuth2 and OpenID Connect scopes in a @useAuth: the generated endpoints require a signed-in user and check no scope,
 * while the OpenAPI document lists them as required. Reported once per @useAuth.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Service[]} services
 */
function reportUnenforcedScopes(program, services) {
  const checked = new Set();
  /** @param {import("@typespec/compiler").Namespace | import("@typespec/compiler").Interface | import("@typespec/compiler").Operation} type */
  const check = (type) => {
    if (checked.has(type)) {
      return;
    }

    checked.add(type);
    const scopes = new Set(
      getAuthentication(program, type)?.options.flatMap((option) => option.schemes.flatMap(scopesOf)) ?? [],
    );
    if (scopes.size > 0) {
      reportDiagnostic(program, {
        code: "scopes-not-enforced",
        format: { scopes: [...scopes].join(", ") },
        target: type,
      });
    }
  };

  for (const service of services) {
    check(service.type);
    navigateTypesInNamespace(service.type, { namespace: check, interface: check, operation: check });
  }
}

/** @param {import("@typespec/http").HttpAuth} scheme */
function scopesOf(scheme) {
  switch (scheme.type) {
    case "oauth2":
      return scheme.flows.flatMap((flow) => flow.scopes.map((scope) => scope.value));
    case "openIdConnect":
      return scheme.scopes ?? [];
    default:
      return [];
  }
}

/**
 * The parent's code-model writer serializes a compiler Numeric as its isInteger field alone, so every constraint number
 * becomes its exact decimal text first, past 2^53 too. A date or duration bound is dropped instead: its ScalarValue
 * would drag the compiler's syntax tree into tspCodeModel.json, and reportUnsupportedBounds has warned about it.
 * @param {any} model
 */
function normalizeConstraints(model) {
  const constraint = new RegExp(constraintPattern);
  const seen = new Set();
  const pending = [model];
  while (pending.length > 0) {
    const node = pending.pop();
    if (node === null || typeof node !== "object" || seen.has(node)) {
      continue;
    }

    seen.add(node);
    if (Array.isArray(node.decorators)) {
      normalizeDecorators(node.decorators, constraint);
    }

    for (const [key, value] of Object.entries(node)) {
      // __raw and compiler entities lead back into the program, which the writer skips as well
      if (key !== "__raw" && !(value !== null && typeof value === "object" && "entityKind" in value)) {
        pending.push(value);
      }
    }
  }
}

/**
 * In place, since several code-model types may share one array.
 * @param {{ name: string, arguments?: Record<string, unknown> }[]} decorators
 * @param {RegExp} constraint
 */
function normalizeDecorators(decorators, constraint) {
  for (let i = decorators.length - 1; i >= 0; i--) {
    if (!constraint.test(decorators[i].name)) {
      continue;
    }

    const args = decorators[i].arguments ?? {};
    for (const [name, value] of Object.entries(args)) {
      if (isNumeric(value)) {
        args[name] = value.toString();
      } else if (value !== null && typeof value === "object") {
        decorators.splice(i, 1);
        break;
      }
    }
  }
}

/**
 * A date or duration bound has no rule in the generated validators; the spec's author hears about it instead of finding
 * out from a request that passes.
 * @param {import("@typespec/compiler").Program} program
 */
function reportUnsupportedBounds(program) {
  /** @param {import("@typespec/compiler").ModelProperty | import("@typespec/compiler").Scalar} type */
  const check = (type) => {
    for (const decorator of type.decorators) {
      const definition = decorator.definition;
      const value = decorator.args[0]?.jsValue;
      if (
        definition?.namespace !== undefined &&
        getNamespaceFullName(definition.namespace) === "TypeSpec" &&
        valueBounds.includes(definition.name) &&
        value !== null &&
        typeof value === "object" &&
        !isNumeric(value)
      ) {
        reportDiagnostic(program, {
          code: "constraint-not-generated",
          format: { decorator: definition.name },
          target: decorator.node ?? type,
        });
      }
    }
  };

  navigateProgram(program, { modelProperty: check, scalar: check });
}

/**
 * The System.Text.Json generator behind a contracts project's JsonSerializerContext cannot see what Vogen generates in
 * the same compilation, so an id beside its context would serialize as an empty object. Typed ids therefore live in a
 * namespace of their own, written by the primitives project; one inside a service namespace is reported and stops the run.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listTypedIds>} typedIds
 * @param {string[]} services
 */
function typedIdsOutsideServices(program, typedIds, services) {
  let outside = true;
  for (const typedId of typedIds) {
    // The service namespace itself, not the namespaces below it: a primitives spec may well sit at Contoso.Admin.Ids
    if (typedId.namespace.length === 0 || services.includes(typedId.namespace)) {
      reportDiagnostic(program, {
        code: "typed-id-in-service-namespace",
        format: {
          scalar: typedId.name,
          namespace: typedId.namespace.length === 0 ? "the global namespace" : `'${typedId.namespace}'`,
        },
        target: typedId.scalar,
      });
      outside = false;
    }
  }

  return outside;
}

/**
 * The primitives run writes the permission classes as it writes the typed ids, so an @permissions enum inside a service
 * namespace is reported and stops the run, like a typed id there.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listPermissions>} permissions
 * @param {string[]} services
 */
function permissionsOutsideServices(program, permissions, services) {
  let outside = true;
  for (const set of permissions) {
    if (set.namespace.length === 0 || services.includes(set.namespace)) {
      reportDiagnostic(program, {
        code: "permissions-in-service-namespace",
        format: {
          enum: set.name,
          namespace: set.namespace.length === 0 ? "the global namespace" : `'${set.namespace}'`,
        },
        target: set.declaration,
      });
      outside = false;
    }
  }

  return outside;
}

/**
 * The class of a @permissions enum nests a class Names holding the permissions as constants, so neither the enum nor one
 * of its members may be called Names in C#, the first letter upper-cased the way the generator does.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listPermissions>} permissions
 */
function permissionsLeaveNamesFree(program, permissions) {
  const isNames = (/** @type {string} */ name) => name.length > 0 && name[0].toUpperCase() + name.slice(1) === "Names";

  let free = true;
  for (const set of permissions) {
    if (isNames(set.name)) {
      reportDiagnostic(program, {
        code: "permission-named-names",
        format: { name: set.name, kind: "enum" },
        target: set.declaration,
      });
      free = false;
    }

    for (const member of set.declaration.members.values()) {
      if (isNames(member.name)) {
        reportDiagnostic(program, {
          code: "permission-named-names",
          format: { name: `${set.name}.${member.name}`, kind: "member" },
          target: member,
        });
        free = false;
      }
    }
  }

  return free;
}
