// A thin wrapper over @typespec/http-client-csharp: selects our .NET plugin (dist/generator) and owns the consumer
// options. Mirrors @azure-typespec/http-client-csharp (docs/reference/azure-http-client-csharp.emitter.ts).
import { createTypeSpecLibrary } from "@typespec/compiler";
import { emitCodeModel } from "@typespec/http-client-csharp";
import { dirname, isAbsolute, resolve } from "node:path";
import { fileURLToPath } from "node:url";

/** MEF export name of the .NET plugin (AspNetCoreServerGenerator in src/). */
const generatorName = "AspNetCoreServerGenerator";

/** Where `npm run build` publishes the plugin. Absolute: the parent resolves relative plugin paths against the output dir. */
const pluginDirectory = fileURLToPath(new URL("../../dist/generator/", import.meta.url));

/** Our decorators reach the .NET generator as InputOperation.Decorators only when listed here (TCGC filters by regex). */
const decoratorPattern = "SpatialFocus\\.Http\\.@.*";

/**
 * Options a consumer may set in tspconfig.yaml; the compiler rejects anything not listed here. The parent's own options
 * (generator-name, plugins, ...) are set below.
 * @type {import("@typespec/compiler").JSONSchemaType<SlimEmitterOptions>}
 */
const optionsSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    "contracts-namespace": {
      type: "string",
      nullable: true,
      description: "C# namespace of the wire-contract records and enums (the Shared project). Default: <service namespace>.Shared",
    },
    "api-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the endpoints, request records and result unions (the Api project). With {interface} in it, every interface gets a namespace and a folder of its own (Contoso.Features.{interface} puts Widgets into Contoso.Features.Widgets and Widgets/); the status case records all interfaces share use the namespace without the placeholder. Default: <service namespace>.Api",
    },
    "client-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the typed HTTP clients (compiled into the consumer). With {interface} in it, every client and its result unions get a namespace and a folder of their own; ApiClientSupport, the {Status}Problem cases and Success use the namespace without the placeholder. Default: <service namespace>.Client",
    },
    "output-type": {
      type: "string",
      enum: ["contracts", "api", "client", "all"],
      nullable: true,
      description: "Which output kind to write: contracts, api, client, or all (default). A single kind is written flat into generated-dir, the way one consumer project generates its own slice.",
    },
    "generated-dir": {
      type: "string",
      nullable: true,
      description: "Where the generated C# files go. Default: src/Generated below emitter-output-dir. Relative paths resolve against the tspconfig.yaml.",
    },
    "save-inputs": {
      type: "boolean",
      nullable: true,
      description: "Keep tspCodeModel.json and Configuration.json next to the output (the generator tests read them).",
    },
    debug: {
      type: "boolean",
      nullable: true,
      description: "Wait for a debugger to attach to the .NET generator process.",
    },
  },
  required: [],
};

/**
 * @typedef {object} SlimEmitterOptions
 * @property {string} [contracts-namespace]
 * @property {string} [api-namespace]
 * @property {string} [client-namespace]
 * @property {"contracts" | "api" | "client" | "all"} [output-type]
 * @property {string} [generated-dir]
 * @property {boolean} [save-inputs]
 * @property {boolean} [debug]
 */

export const $lib = createTypeSpecLibrary({
  name: "@spatialfocus/typespec-http-csharp-slim",
  diagnostics: {},
  emitter: { options: optionsSchema },
});

/**
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 */
export async function $onEmit(context) {
  const [, diagnostics] = await emitSlimCodeModel(context);
  context.program.reportDiagnostics(diagnostics);
}

/**
 * Our defaults, then the parent's emitCodeModel. Exposed so a downstream emitter can pass its own updateCodeModel, the
 * hook for re-injecting what TCGC drops (e.g. @error responses).
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 * @param {(model: any, sdkContext: any) => any} [updateCodeModel]
 */
export async function emitSlimCodeModel(context, updateCodeModel) {
  /** @type {Record<string, unknown>} */
  const options = context.options;
  options["generator-name"] = generatorName;
	options["plugins"] = [pluginDirectory];

  // Relative to the tspconfig, not to wherever tsp was started
  const generatedDir = options["generated-dir"];
  if (typeof generatedDir === "string" && !isAbsolute(generatedDir)) {
    const config = context.program.compilerOptions.config;
    options["generated-dir"] = resolve(config ? dirname(config) : context.program.projectRoot, generatedDir);
  }

  // No client is emitted, so nothing "references" the models
  options["unreferenced-types-handling"] = "keepAll";
  options["sdk-context-options"] = { additionalDecorators: [decoratorPattern] };
  return await emitCodeModel(/** @type {any} */ (context), updateCodeModel);
}
