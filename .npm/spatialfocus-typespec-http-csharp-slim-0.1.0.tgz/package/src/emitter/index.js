// A thin wrapper over @typespec/http-client-csharp: selects our .NET plugin (dist/generator) and owns the consumer
// options. Mirrors @azure-typespec/http-client-csharp (docs/reference/azure-http-client-csharp.emitter.ts).
import { createTypeSpecLibrary, getNamespaceFullName, isNumeric, listServices, navigateProgram } from "@typespec/compiler";
import { emitCodeModel } from "@typespec/http-client-csharp";
import { dirname, isAbsolute, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { diagnostics, libraryName, listTypedIds, reportDiagnostic } from "./lib/lib.js";

/** MEF export name of the .NET plugin (AspNetCoreServerGenerator in src/). */
const generatorName = "AspNetCoreServerGenerator";

/** Where `npm run build` publishes the plugin. Absolute: the parent resolves relative plugin paths against the output dir. */
const pluginDirectory = fileURLToPath(new URL("../../dist/generator/", import.meta.url));

/** Our decorators reach the .NET generator as InputOperation.Decorators only when listed here (TCGC filters by regex). */
const decoratorPattern = "SpatialFocus\\.Http\\.@.*";

/** TypeSpec's constraint decorators, listed only with validation on; Spec/Constraints.cs reads them. */
const constraintPattern =
  "^TypeSpec\\.@(minLength|maxLength|pattern|minValue|maxValue|minValueExclusive|maxValueExclusive|minItems|maxItems)$";

/** The bounds that also take dates and durations, which the generated validators do not check. */
const valueBounds = ["@minValue", "@maxValue", "@minValueExclusive", "@maxValueExclusive"];

/**
 * Options a consumer may set in tspconfig.yaml; the compiler rejects anything not listed here. The parent's own options
 * (generator-name, plugins, ...) are set below.
 * @type {import("@typespec/compiler").JSONSchemaType<SlimEmitterOptions>}
 */
const optionsSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    "contracts-namespace": {
      type: "string",
      nullable: true,
      description: "C# namespace of the wire-contract records and enums (the Shared project). Default: <service namespace>.Shared",
    },
    "api-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the endpoints, request records and result unions (the Api project). With {interface} in it, every interface gets a namespace and a folder of its own (Contoso.Features.{interface} puts Widgets into Contoso.Features.Widgets and Widgets/); the status case records all interfaces share use the namespace without the placeholder. Default: <service namespace>.Api",
    },
    "client-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the typed HTTP clients (compiled into the consumer). With {interface} in it, every client and its result unions get a namespace and a folder of their own; ApiClientSupport, the {Status}Problem cases and Success use the namespace without the placeholder. Default: <service namespace>.Client",
    },
    "output-type": {
      type: "string",
      enum: ["contracts", "api", "client", "primitives", "all"],
      nullable: true,
      description:
        "Which output kind to write: contracts, api, client, primitives, or all (default: contracts, api and client). A single kind is written flat into generated-dir, the way one consumer project generates its own slice. primitives writes the Vogen value object of every @typedId scalar of the program into the scalar's own namespace, for the one project every service shares.",
    },
    "generated-dir": {
      type: "string",
      nullable: true,
      description: "Where the generated C# files go. Default: src/Generated below emitter-output-dir. Relative paths resolve against the tspconfig.yaml.",
    },
    validation: {
      type: "string",
      enum: ["none", "fluentvalidation"],
      nullable: true,
      description:
        "Validators from TypeSpec's constraint decorators (@minLength, @pattern, @minValue, ...): none (default) or fluentvalidation. The contracts output gets a FluentValidation validator per input model, the api output one per request and an endpoint filter that answers an invalid request with a 400 before the handler runs. The projects compiling that output reference FluentValidation.",
    },
    "save-inputs": {
      type: "boolean",
      nullable: true,
      description: "Keep tspCodeModel.json and Configuration.json next to the output (the generator tests read them).",
    },
    debug: {
      type: "boolean",
      nullable: true,
      description: "Wait for a debugger to attach to the .NET generator process.",
    },
  },
  required: [],
};

/**
 * @typedef {object} SlimEmitterOptions
 * @property {string} [contracts-namespace]
 * @property {string} [api-namespace]
 * @property {string} [client-namespace]
 * @property {"contracts" | "api" | "client" | "primitives" | "all"} [output-type]
 * @property {string} [generated-dir]
 * @property {"none" | "fluentvalidation"} [validation]
 * @property {boolean} [save-inputs]
 * @property {boolean} [debug]
 */

export const $lib = createTypeSpecLibrary({
  name: libraryName,
  diagnostics,
  emitter: { options: optionsSchema },
});

/**
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 */
export async function $onEmit(context) {
  const [, diagnostics] = await emitSlimCodeModel(context);
  context.program.reportDiagnostics(diagnostics);
}

/**
 * Our defaults, then the parent's emitCodeModel. Exposed so a downstream emitter can pass its own updateCodeModel, the
 * hook for re-injecting what TCGC drops (e.g. @error responses).
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 * @param {(model: any, sdkContext: any) => any} [updateCodeModel]
 */
export async function emitSlimCodeModel(context, updateCodeModel) {
  /** @type {Record<string, unknown>} */
  const options = context.options;
  options["generator-name"] = generatorName;
  options["plugins"] = [pluginDirectory];

  // Relative to the tspconfig, not to wherever tsp was started
  const generatedDir = options["generated-dir"];
  if (typeof generatedDir === "string" && !isAbsolute(generatedDir)) {
    const config = context.program.compilerOptions.config;
    options["generated-dir"] = resolve(config ? dirname(config) : context.program.projectRoot, generatedDir);
  }

  // The code model lists models, enums and clients but no scalars: a typed id nothing references would never reach the
  // generator, and no scalar doc does. The decorator state has every one, so the list travels as an option, which the
  // parent passes through to Configuration.json unchanged
  const typedIds = listTypedIds(context.program);
  const services = listServices(context.program).map((service) => getNamespaceFullName(service.type));
  if (!typedIdsOutsideServices(context.program, typedIds, services)) {
    return [undefined, []];
  }
  options["typed-ids"] = typedIds.map(({ scalar, ...typedId }) => typedId);

  // A primitives spec has no @service, and without a root namespace the parent skips generation
  // (https://github.com/microsoft/typespec/issues/10914). TCGC takes the namespace as an override, which names the code
  // model and, with no models in the program, moves nothing
  if (options["output-type"] === "primitives" && services.length === 0) {
    options["namespace"] = typedIds[0]?.namespace ?? "Primitives";
  }

  // No client is emitted, so nothing "references" the models
  options["unreferenced-types-handling"] = "keepAll";
  if (options["validation"] !== "fluentvalidation") {
    options["sdk-context-options"] = { additionalDecorators: [decoratorPattern] };
    return await emitCodeModel(/** @type {any} */ (context), updateCodeModel);
  }

  reportUnsupportedBounds(context.program);
  options["sdk-context-options"] = { additionalDecorators: [decoratorPattern, constraintPattern] };
  return await emitCodeModel(/** @type {any} */ (context), (model, sdkContext) => {
    normalizeConstraints(model);
    return updateCodeModel ? updateCodeModel(model, sdkContext) : model;
  });
}

/**
 * The parent's code-model writer serializes a compiler Numeric as its isInteger field alone, so every constraint number
 * becomes its exact decimal text first, past 2^53 too. A date or duration bound is dropped instead: its ScalarValue
 * would drag the compiler's syntax tree into tspCodeModel.json, and reportUnsupportedBounds has warned about it.
 * @param {any} model
 */
function normalizeConstraints(model) {
  const constraint = new RegExp(constraintPattern);
  const seen = new Set();
  const pending = [model];
  while (pending.length > 0) {
    const node = pending.pop();
    if (node === null || typeof node !== "object" || seen.has(node)) {
      continue;
    }

    seen.add(node);
    if (Array.isArray(node.decorators)) {
      normalizeDecorators(node.decorators, constraint);
    }

    for (const [key, value] of Object.entries(node)) {
      // __raw and compiler entities lead back into the program, which the writer skips as well
      if (key !== "__raw" && !(value !== null && typeof value === "object" && "entityKind" in value)) {
        pending.push(value);
      }
    }
  }
}

/**
 * In place, since several code-model types may share one array.
 * @param {{ name: string, arguments?: Record<string, unknown> }[]} decorators
 * @param {RegExp} constraint
 */
function normalizeDecorators(decorators, constraint) {
  for (let i = decorators.length - 1; i >= 0; i--) {
    if (!constraint.test(decorators[i].name)) {
      continue;
    }

    const args = decorators[i].arguments ?? {};
    for (const [name, value] of Object.entries(args)) {
      if (isNumeric(value)) {
        args[name] = value.toString();
      } else if (value !== null && typeof value === "object") {
        decorators.splice(i, 1);
        break;
      }
    }
  }
}

/**
 * A date or duration bound has no rule in the generated validators; the spec's author hears about it instead of finding
 * out from a request that passes.
 * @param {import("@typespec/compiler").Program} program
 */
function reportUnsupportedBounds(program) {
  /** @param {import("@typespec/compiler").ModelProperty | import("@typespec/compiler").Scalar} type */
  const check = (type) => {
    for (const decorator of type.decorators) {
      const definition = decorator.definition;
      const value = decorator.args[0]?.jsValue;
      if (
        definition?.namespace !== undefined &&
        getNamespaceFullName(definition.namespace) === "TypeSpec" &&
        valueBounds.includes(definition.name) &&
        value !== null &&
        typeof value === "object" &&
        !isNumeric(value)
      ) {
        reportDiagnostic(program, {
          code: "constraint-not-generated",
          format: { decorator: definition.name },
          target: decorator.node ?? type,
        });
      }
    }
  };

  navigateProgram(program, { modelProperty: check, scalar: check });
}

/**
 * The System.Text.Json generator behind a contracts project's JsonSerializerContext cannot see what Vogen generates in
 * the same compilation, so an id beside its context would serialize as an empty object. Typed ids therefore live in a
 * namespace of their own, written by the primitives project; one inside a service namespace is reported and stops the run.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listTypedIds>} typedIds
 * @param {string[]} services
 */
function typedIdsOutsideServices(program, typedIds, services) {
  let outside = true;
  for (const typedId of typedIds) {
    // The service namespace itself, not the namespaces below it: a primitives spec may well sit at Contoso.Admin.Ids
    if (typedId.namespace.length === 0 || services.includes(typedId.namespace)) {
      reportDiagnostic(program, {
        code: "typed-id-in-service-namespace",
        format: {
          scalar: typedId.name,
          namespace: typedId.namespace.length === 0 ? "the global namespace" : `'${typedId.namespace}'`,
        },
        target: typedId.scalar,
      });
      outside = false;
    }
  }

  return outside;
}
