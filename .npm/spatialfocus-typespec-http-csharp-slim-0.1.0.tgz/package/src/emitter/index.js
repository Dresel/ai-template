// A thin wrapper over @typespec/http-client-csharp: selects our .NET plugin (dist/generator) and owns the consumer
// options. Mirrors @azure-typespec/http-client-csharp (docs/reference/azure-http-client-csharp.emitter.ts).
import {
  createTypeSpecLibrary,
  getFriendlyName,
  getNamespaceFullName,
  isNullType,
  isNumeric,
  listServices,
  navigateProgram,
  navigateTypesInNamespace,
  NoTarget,
} from "@typespec/compiler";
import { isEvents } from "@typespec/events";
import { unsafe_getEventDefinitions as getEventDefinitions } from "@typespec/events/experimental";
import { getAllHttpServices, getAuthentication, getAuthenticationForOperation } from "@typespec/http";
import { getStreamMetadata } from "@typespec/http/experimental";
import { emitCodeModel } from "@typespec/http-client-csharp";
import { isTerminalEvent } from "@typespec/sse";
import { dirname, isAbsolute, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  diagnostics,
  fullName,
  isAnonymous,
  isPermissionSet,
  libraryName,
  listPermissions,
  listTypedIds,
  permissionScalarOf,
  reportDiagnostic,
  requiredPermissionsOf,
} from "./lib/lib.js";

/** MEF export name of the .NET plugin (AspNetCoreServerGenerator in src/). */
const generatorName = "AspNetCoreServerGenerator";

/** Where `npm run build` publishes the plugin. Absolute: the parent resolves relative plugin paths against the output dir. */
const pluginDirectory = fileURLToPath(new URL("../../dist/generator/", import.meta.url));

/**
 * The decorators TCGC passes to the code model, by name: it throws past the first argument of a rest parameter such as
 * @requiresPermission's (getTypeDecorators in its internal-utils.js). Match SpatialFocus.Http again once it names them.
 */
const decoratorPattern = "^SpatialFocus\\.Http\\.@(httpQuery|typedId)$";

/** What the authorization pass attaches to a code-model operation, read by Spec/Authorization.cs. */
const authorizationDecorator = "SpatialFocus.Http.@authorization";

/** What a server-sent event operation streams, read by Spec/ServerEvents.cs. */
const serverSentEventsDecorator = "SpatialFocus.Http.@serverSentEvents";

/** TypeSpec's constraint decorators, listed only with validation on; Spec/Constraints.cs reads them. */
const constraintPattern =
  "^TypeSpec\\.@(minLength|maxLength|pattern|minValue|maxValue|minValueExclusive|maxValueExclusive|minItems|maxItems)$";

/** The bounds that also take dates and durations, which the generated validators do not check. */
const valueBounds = ["@minValue", "@maxValue", "@minValueExclusive", "@maxValueExclusive"];

/**
 * Options a consumer may set in tspconfig.yaml; the compiler rejects anything not listed here. The parent's own options
 * (generator-name, plugins, ...) are set below.
 * @type {import("@typespec/compiler").JSONSchemaType<SlimEmitterOptions>}
 */
const optionsSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    "contracts-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the wire-contract records and enums (the Shared project). With {feature} in it, the models and enums of a TypeSpec namespace below the service get a namespace and a folder of their own (Contoso.Shared.{feature} puts the models of Contoso.Billing into Contoso.Shared.Billing and Billing/); the JSON context and the problem types use the namespace without the placeholder. Default: <service namespace>.Shared",
    },
    "api-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the endpoints, request records and result unions (the Api project). With {interface} in it, every interface gets a namespace and a folder of its own (Contoso.Features.{interface} puts Widgets into Contoso.Features.Widgets and Widgets/). With {feature}, the interfaces of a TypeSpec namespace below the service share one (Contoso.Features.{feature}.{interface} puts Contoso.Billing's Payers into Contoso.Features.Billing.Payers and Billing/Payers/), and the type names drop the feature in front. The status case records all interfaces share use the namespace without the placeholders. Default: <service namespace>.Api",
    },
    "client-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the typed HTTP clients (compiled into the consumer). With {interface} in it, every client and its result unions get a namespace and a folder of their own, and {feature} works as in api-namespace. ApiClientSupport, the {Status}Problem cases and Success use the namespace without the placeholders. Default: <service namespace>.Client",
    },
    "library-namespace": {
      type: "string",
      nullable: true,
      description:
        "C# namespace of the library project, which output-type: library writes: ProblemDetails, ValidationProblemDetails with Violation and ViolationSeverity, PermissionRequirement and RequiresPermissionAttribute, and the client's ApiFailure, ApiOutcome, IProblemOf, Success and ServerEventReader. Set on a contracts, api or client run, that run writes none of them and references this namespace instead, so several services, or the features of one app with projects of their own, share one of each. Default: unset, every run writes the ones it uses.",
    },
    "output-type": {
      type: "string",
      enum: ["contracts", "api", "client", "primitives", "library", "all"],
      nullable: true,
      description:
        "Which output kind to write: contracts, api, client, primitives, library, or all (default: contracts, api and client). A single kind is written flat into generated-dir, the way one consumer project generates its own slice. primitives writes the Vogen value objects of the @typedId scalars and the classes of the @permissions enums, of the namespace primitives-namespace names or of the whole program. library writes the library types into library-namespace, for the one project the services that set library-namespace share.",
    },
    "primitives-namespace": {
      type: "string",
      nullable: true,
      description:
        "For output-type: primitives, the C# namespace this project writes: the @typedId scalars declared in it and the classes of the @permissions enums that land in it. What the spec imports from other namespaces, such as the spine's ids in a feature's project, is referenced and not written, and the permission scalar gets no All. Default: unset, the run writes the whole program, whose typed ids and permission classes then share one namespace, and gives the permission scalar its All.",
    },
    "permission-list": {
      type: "string",
      nullable: true,
      description:
        "For output-type: primitives with primitives-namespace, the name of a class the run writes into that namespace, whose All lists every permission of the program: the product's, when the spec imports the permission sets the product includes. Default: unset, no list.",
    },
    "generated-dir": {
      type: "string",
      nullable: true,
      description: "Where the generated C# files go. Default: src/Generated below emitter-output-dir. Relative paths resolve against the tspconfig.yaml.",
    },
    validation: {
      type: "string",
      enum: ["none", "fluentvalidation"],
      nullable: true,
      description:
        "Validators from TypeSpec's constraint decorators (@minLength, @pattern, @minValue, ...): none (default) or fluentvalidation. The contracts output gets a FluentValidation validator per input model, the api output one per request and an endpoint filter that answers an invalid request with a 400 before the handler runs. The projects compiling that output reference FluentValidation.",
    },
    "save-inputs": {
      type: "boolean",
      nullable: true,
      description: "Keep tspCodeModel.json and Configuration.json next to the output (the generator tests read them).",
    },
    debug: {
      type: "boolean",
      nullable: true,
      description: "Wait for a debugger to attach to the .NET generator process.",
    },
  },
  required: [],
};

/**
 * @typedef {object} SlimEmitterOptions
 * @property {string} [contracts-namespace]
 * @property {string} [api-namespace]
 * @property {string} [client-namespace]
 * @property {string} [library-namespace]
 * @property {"contracts" | "api" | "client" | "primitives" | "library" | "all"} [output-type]
 * @property {string} [primitives-namespace]
 * @property {string} [permission-list]
 * @property {string} [generated-dir]
 * @property {"none" | "fluentvalidation"} [validation]
 * @property {boolean} [save-inputs]
 * @property {boolean} [debug]
 */

export const $lib = createTypeSpecLibrary({
  name: libraryName,
  diagnostics,
  emitter: { options: optionsSchema },
});

/**
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 */
export async function $onEmit(context) {
  const [, diagnostics] = await emitSlimCodeModel(context);

  // TCGC tries every union as an enum and warns about an @events union, whose variants are models by design
  context.program.reportDiagnostics(
    diagnostics.filter(
      (diagnostic) =>
        !diagnostic.code.endsWith("/union-enums-invalid-kind") ||
        diagnostic.target?.kind !== "Union" ||
        !isEvents(context.program, diagnostic.target),
    ),
  );
}

/**
 * Our defaults, then the parent's emitCodeModel. Exposed so a downstream emitter can pass its own updateCodeModel, the
 * hook for re-injecting what TCGC drops (e.g. @error responses).
 * @param {import("@typespec/compiler").EmitContext<SlimEmitterOptions>} context
 * @param {(model: any, sdkContext: any) => any} [updateCodeModel]
 */
export async function emitSlimCodeModel(context, updateCodeModel) {
  /** @type {Record<string, unknown>} */
  const options = context.options;
  options["generator-name"] = generatorName;
  options["plugins"] = [pluginDirectory];

  // Relative to the tspconfig, not to wherever tsp was started
  const generatedDir = options["generated-dir"];
  if (typeof generatedDir === "string" && !isAbsolute(generatedDir)) {
    const config = context.program.compilerOptions.config;
    options["generated-dir"] = resolve(config ? dirname(config) : context.program.projectRoot, generatedDir);
  }

  // The code model has no scalars, and holds the enums of a service namespace only, so the typed ids and the permission
  // enums travel from the decorator state as options, which the parent passes through to Configuration.json unchanged
  const typedIds = listTypedIds(context.program);
  const permissions = listPermissions(context.program);
  const services = listServices(context.program);
  const serviceNames = services.map((service) => getNamespaceFullName(service.type));

  // Every check runs before the run stops, so one compile reports them all
  const typedIdsOutside = typedIdsOutsideServices(context.program, typedIds, serviceNames);
  const permissionsOutside = permissionsOutsideServices(context.program, permissions, serviceNames);
  const onePermissionType = onePermissionTypePerService(context.program, services);
  const namesFree = permissionsLeaveNamesFree(context.program, permissions);
  const classesDistinct = permissionClassesDistinct(context.program, permissions);
  const permissionNames = permissionNamesDistinct(context.program, permissions);
  const typedIdNames = typedIdNamesDistinct(context.program, typedIds);
  const contractsDistinct = contractNamesDistinct(context.program, services, options["contracts-namespace"]);
  const streams = serverSentEventStreams(context.program);
  const libraryComplete = libraryOptionsComplete(context.program, options, permissions);
  const primitivesComplete = primitivesOptionsComplete(context.program, options, typedIds, permissions);
  if (
    !typedIdsOutside ||
    !permissionsOutside ||
    !onePermissionType ||
    !namesFree ||
    !classesDistinct ||
    !permissionNames ||
    !typedIdNames ||
    !contractsDistinct ||
    streams === undefined ||
    !libraryComplete ||
    !primitivesComplete
  ) {
    return [undefined, []];
  }

  options["typed-ids"] = typedIds.map(({ scalar, ...typedId }) => typedId);
  options["permissions"] = permissions.map(({ declaration, ...set }) => set);
  reportUnenforcedScopes(context.program, services);

  // A primitives or library spec has no @service, and without a root namespace the parent skips generation
  // (https://github.com/microsoft/typespec/issues/10914). TCGC takes the namespace as an override, which names the code
  // model and, with no models in the program, moves nothing
  const outputType = options["output-type"];
  if ((outputType === "primitives" || outputType === "library") && services.length === 0) {
    options["namespace"] =
      (outputType === "primitives" ? options["primitives-namespace"] : undefined) ?? typedIds[0]?.namespace ?? "Primitives";
  }

  // No client is emitted, so nothing "references" the models
  options["unreferenced-types-handling"] = "keepAll";
  const validation = options["validation"] === "fluentvalidation";
  if (validation) {
    reportUnsupportedBounds(context.program);
  }

  options["sdk-context-options"] = {
    additionalDecorators: validation ? [decoratorPattern, constraintPattern] : [decoratorPattern],
  };
  const typedIdScalars = new Set(typedIds.map((typedId) => typedId.scalar));
  return await emitCodeModel(/** @type {any} */ (context), (model, sdkContext) => {
    dropFriendlyNamePrefixes(context.program, sdkContext);
    attachServerSentEvents(sdkContext, streams);
    attachAuthorization(context.program, model, sdkContext);
    if (validation) {
      normalizeConstraints(model);
    }

    passDefaults(context.program, sdkContext, typedIdScalars);
    return updateCodeModel ? updateCodeModel(model, sdkContext) : model;
  });
}

/**
 * A library run needs the namespace it writes into, and the one scalar its PermissionRequirement holds. Reported here,
 * so the run stops before the generator starts.
 * @param {import("@typespec/compiler").Program} program
 * @param {Record<string, unknown>} options
 * @param {readonly { scalar: string }[]} permissions
 * @returns {boolean}
 */
function libraryOptionsComplete(program, options, permissions) {
  if (options["output-type"] !== "library") {
    return true;
  }

  let complete = true;
  if (typeof options["library-namespace"] !== "string" || options["library-namespace"].length === 0) {
    reportDiagnostic(program, { code: "library-namespace-missing", target: NoTarget });
    complete = false;
  }

  const scalars = [...new Set(permissions.map((set) => set.scalar))].sort();
  if (scalars.length > 1) {
    reportDiagnostic(program, {
      code: "library-permission-types",
      format: { scalars: scalars.join(", ") },
      target: NoTarget,
    });
    complete = false;
  }

  return complete;
}

/**
 * primitives-namespace and permission-list configure a primitives run, and that run must write what they select.
 * Without primitives-namespace it writes the whole program, whose scalar's All is complete only over one namespace: a
 * feature project that forgot the option would also write the spine's types it imports.
 * @param {import("@typespec/compiler").Program} program
 * @param {Record<string, unknown>} options
 * @param {ReturnType<typeof listTypedIds>} typedIds
 * @param {ReturnType<typeof listPermissions>} permissions
 * @returns {boolean}
 */
function primitivesOptionsComplete(program, options, typedIds, permissions) {
  const namespace = nonEmpty(options["primitives-namespace"]);
  const list = nonEmpty(options["permission-list"]);
  if (options["output-type"] !== "primitives") {
    if (namespace === undefined && list === undefined) {
      return true;
    }

    reportDiagnostic(program, {
      code: "primitives-options-misplaced",
      format: { kind: String(options["output-type"] ?? "all") },
      target: NoTarget,
    });
    return false;
  }

  const classes = permissions.map(permissionClassOf);
  const declared = [...new Set([...typedIds.map((typedId) => typedId.namespace), ...classes.map((c) => c.namespace)])];
  const namespaces = declared.length > 0 ? declared.sort().join(", ") : "no namespace";
  if (namespace === undefined) {
    if (list !== undefined) {
      reportDiagnostic(program, { code: "permission-list-without-namespace", target: NoTarget });
      return false;
    }

    if (declared.length > 1) {
      reportDiagnostic(program, { code: "primitives-namespace-missing", format: { namespaces }, target: NoTarget });
      return false;
    }

    return true;
  }

  const written = [
    ...typedIds.filter((typedId) => typedId.namespace === namespace).map((typedId) => typedId.name),
    ...classes.filter((c) => c.namespace === namespace).map((c) => c.name),
  ];
  if (written.length === 0 && (list === undefined || permissions.length === 0)) {
    reportDiagnostic(program, { code: "primitives-namespace-empty", format: { namespace, namespaces }, target: NoTarget });
    return false;
  }

  let complete = true;
  if (list !== undefined && written.includes(list)) {
    reportDiagnostic(program, { code: "permission-list-name-taken", format: { name: list, namespace }, target: NoTarget });
    complete = false;
  }

  const scalars = [...new Set(permissions.map((set) => set.scalar))].sort();
  if (list !== undefined && scalars.length > 1) {
    reportDiagnostic(program, {
      code: "permission-list-types",
      format: { scalars: scalars.join(", ") },
      target: NoTarget,
    });
    complete = false;
  }

  return complete;
}

/**
 * An option's text, undefined when unset or empty.
 * @param {unknown} value
 * @returns {string | undefined}
 */
function nonEmpty(value) {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

/**
 * The operations answering server-sent events, each with its one event: the name on the wire and the model of its data.
 * A shape the generated code does not support is reported, and undefined stops the run like the other checks.
 * @param {import("@typespec/compiler").Program} program
 * @returns {Map<import("@typespec/compiler").Operation, { eventType: string, type: string }> | undefined}
 */
function serverSentEventStreams(program) {
  const streams = new Map();
  let supported = true;
  const [services] = getAllHttpServices(program);
  for (const operation of services.flatMap((service) => service.operations)) {
    const contents = operation.responses.flatMap((response) => response.responses);
    const stream = contents
      .map((content) => getStreamMetadata(program, content)?.streamType)
      .find((type) => type?.kind === "Union" && isEvents(program, type));
    if (stream === undefined) {
      continue;
    }

    const [events] = getEventDefinitions(program, stream);
    const reason = unsupportedStream(program, operation, events ?? []);
    if (reason !== undefined) {
      reportDiagnostic(program, {
        code: "server-sent-events-unsupported",
        format: { operation: operation.operation.name, reason },
        target: operation.operation,
      });
      supported = false;
      continue;
    }

    streams.set(operation.operation, { eventType: events[0].eventType, type: fullName(events[0].payloadType) });
  }

  return supported ? streams : undefined;
}

/**
 * What keeps the generated code from serving a server-sent event operation, undefined for the supported shape: one named
 * event of JSON model data, path and query parameters only, and no response beside the stream.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/http").HttpOperation} operation
 * @param {readonly any[]} events
 * @returns {string | undefined}
 */
function unsupportedStream(program, operation, events) {
  if (operation.responses.length > 1) {
    return "a response beside the stream";
  }

  const { body, parameters } = operation.parameters;
  if (body !== undefined || parameters.some((parameter) => parameter.type !== "path" && parameter.type !== "query")) {
    return "a parameter outside the path and the query";
  }

  if (events.length !== 1) {
    return events.length === 0 ? "a stream without events" : "a stream of several event types";
  }

  const [event] = events;
  if (event.eventType === undefined) {
    return "an event without a name, which a named union variant gives it";
  }

  if (isTerminalEvent(program, event.root)) {
    return "a terminal event";
  }

  if (event.isEventEnvelope) {
    return "an event envelope";
  }

  if (event.payloadType.kind !== "Model") {
    return "event data that is no model";
  }

  if (event.payloadContentType !== undefined && !/[/+]json$/.test(event.payloadContentType)) {
    return "event data that is no JSON";
  }

  return undefined;
}

/**
 * The parent's code model keeps the stream's payload but drops the event names, so each stream travels to the
 * generator as the synthetic @serverSentEvents decorator on its operation.
 * @param {any} sdkContext
 * @param {Map<import("@typespec/compiler").Operation, { eventType: string, type: string }>} streams
 */
function attachServerSentEvents(sdkContext, streams) {
  for (const [sdkOperation, inputOperation] of sdkContext.__typeCache.operations) {
    const stream = streams.get(sdkOperation.__raw?.operation);
    if (stream !== undefined) {
      inputOperation.decorators = [
        ...(inputOperation.decorators ?? []),
        { name: serverSentEventsDecorator, arguments: stream },
      ];
    }
  }
}

/**
 * TCGC names a type after its @friendlyName, and a dotted one, `Primitives.GroupId`, prefixes the OpenAPI schema with a
 * namespace. A C# name holds no dot, so it keeps the last segment.
 * @param {import("@typespec/compiler").Program} program
 * @param {any} sdkContext
 */
function dropFriendlyNamePrefixes(program, sdkContext) {
  for (const [sdkType, inputType] of sdkContext.__typeCache.types) {
    const friendlyName = sdkType.__raw ? getFriendlyName(program, sdkType.__raw) : undefined;
    if (friendlyName?.includes(".") && inputType.name === friendlyName) {
      inputType.name = friendlyName.slice(friendlyName.lastIndexOf(".") + 1);
    }
  }
}

/** The standard scalars whose values a C# parameter default can hold. */
const constantScalars = [
  "string",
  "boolean",
  "int8",
  "int16",
  "int32",
  "int64",
  "uint8",
  "uint16",
  "uint32",
  "uint64",
  "safeint",
  "float32",
  "float64",
  "decimal",
  "decimal128",
];

/**
 * The TypeSpec default of an optional member, which TCGC drops, as text in the parent's defaultValue slot: a number's
 * exact digits, true or false, a string, an enum member's name. One no C# constant holds is reported and left out.
 * @param {import("@typespec/compiler").Program} program
 * @param {any} sdkContext
 * @param {Set<import("@typespec/compiler").Scalar>} typedIdScalars
 */
function passDefaults(program, sdkContext, typedIdScalars) {
  const cache = sdkContext.__typeCache;
  const reported = new Set();

  // The model members, the operation parameters the endpoints bind and the method parameters the clients take
  for (const references of [cache.properties, cache.operationParameters, cache.methodParmeters]) {
    for (const [sdkProperty, inputProperty] of references) {
      /** @type {import("@typespec/compiler").ModelProperty | undefined} */
      const property = sdkProperty.__raw;
      if (
        property?.kind !== "ModelProperty" ||
        !property.optional ||
        property.defaultValue === undefined ||
        property.defaultValue.valueKind === "NullValue" ||
        inputProperty.defaultValue !== undefined
      ) {
        continue;
      }

      const text = defaultText(property, typedIdScalars);
      if (text !== undefined) {
        inputProperty.defaultValue = {
          type: { kind: "string", name: "string", crossLanguageDefinitionId: "TypeSpec.string" },
          value: text,
        };
      } else if (!reported.has(property)) {
        reported.add(property);
        reportDiagnostic(program, {
          code: "default-not-generated",
          format: { property: property.name },
          target: property.defaultValue.node ?? property,
        });
      }
    }
  }
}

/**
 * The default as the generator reads it, or undefined where C# has no constant for it: a date, a uuid, a typed id, an
 * array or a model.
 * @param {import("@typespec/compiler").ModelProperty} property
 * @param {Set<import("@typespec/compiler").Scalar>} typedIdScalars
 * @returns {string | undefined}
 */
function defaultText(property, typedIdScalars) {
  const value = property.defaultValue;
  const type = withoutNull(property.type);
  switch (value?.valueKind) {
    case "NumericValue":
      return isConstantScalar(type, typedIdScalars) ? value.value.toString() : undefined;
    case "StringValue":
      return isConstantScalar(type, typedIdScalars) ? value.value : undefined;
    case "BooleanValue":
      return String(value.value);
    case "EnumValue":
      return type.kind === "Enum" ? value.value.name : undefined;
    default:
      return undefined;
  }
}

/**
 * The type of `T | null`, which the generator maps to the nullable form of T.
 * @param {import("@typespec/compiler").Type} type
 */
function withoutNull(type) {
  if (type.kind !== "Union") {
    return type;
  }

  const variants = [...type.variants.values()].filter((variant) => !isNullType(variant.type));
  return variants.length === 1 ? variants[0].type : type;
}

/**
 * A standard scalar or one deriving from it, with no uuid or typed id on the way: those are structs in C#.
 * @param {import("@typespec/compiler").Type} type
 * @param {Set<import("@typespec/compiler").Scalar>} typedIdScalars
 */
function isConstantScalar(type, typedIdScalars) {
  for (let scalar = type.kind === "Scalar" ? type : undefined; scalar; scalar = scalar.baseScalar) {
    const namespace = scalar.namespace ? getNamespaceFullName(scalar.namespace) : "";
    if (typedIdScalars.has(scalar) || (namespace === "SpatialFocus.Http" && scalar.name === "uuid")) {
      return false;
    }

    if (namespace === "TypeSpec") {
      return constantScalars.includes(scalar.name);
    }
  }

  return false;
}

/**
 * Each operation's resolved @useAuth and permissions as a decorator on its code-model operation, since the parent keeps
 * only the service's scheme and TCGC drops our decorators. None where no @useAuth resolves.
 * @param {import("@typespec/compiler").Program} program
 * @param {any} model
 * @param {any} sdkContext
 */
function attachAuthorization(program, model, sdkContext) {
  /** @type {Map<string, import("@typespec/compiler").Operation>} */
  const operations = new Map();
  const pending = [...sdkContext.sdkPackage.clients];
  while (pending.length > 0) {
    const client = pending.pop();
    pending.push(...(client.children ?? []));
    for (const method of client.methods ?? []) {
      const operation = method.__raw ?? method.operation?.__raw?.operation;
      if (operation !== undefined) {
        operations.set(method.crossLanguageDefinitionId, operation);
      }
    }
  }

  // A child client may also be listed at the top level, so an operation is decorated once
  const seen = new Set();
  const clients = [...model.clients];
  while (clients.length > 0) {
    const client = clients.pop();
    clients.push(...(client.children ?? []));
    for (const method of client.methods ?? []) {
      const operation = operations.get(method.operation.crossLanguageDefinitionId);
      const access = operation === undefined || seen.has(method.operation) ? undefined : accessOf(program, operation);
      seen.add(method.operation);
      if (access !== undefined) {
        // A new array: TCGC hands the method's decorators to the operation, and they may be shared further
        method.operation.decorators = [
          ...(method.operation.decorators ?? []),
          { name: authorizationDecorator, arguments: access },
        ];
      }
    }
  }
}

/**
 * What an operation requires of its caller: nothing stated without a @useAuth, no user where it lets one without a token
 * through, otherwise a signed-in user and the permissions of the interface and the operation, by their full names.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Operation} operation
 */
function accessOf(program, operation) {
  const authentication = getAuthenticationForOperation(program, operation);
  if (authentication === undefined) {
    return undefined;
  }

  if (isAnonymous(authentication)) {
    return { access: "anonymous" };
  }

  const members = requiredPermissionsOf(program, operation);
  const scalar = members.length > 0 ? permissionScalarOf(program, members[0]) : undefined;
  return scalar === undefined
    ? { access: "authenticated" }
    : {
        access: "authenticated",
        type: fullName(scalar),
        permissions: members.map((member) => `${fullName(member.enum)}.${member.name}`),
      };
}

/**
 * The generated requirement takes one permission type, so a service whose operations require permissions of two
 * scalars is reported and stops the run.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Service[]} services
 */
function onePermissionTypePerService(program, services) {
  let one = true;
  for (const service of services) {
    /** @type {Set<string>} */
    const scalars = new Set();
    navigateTypesInNamespace(service.type, {
      operation(operation) {
        for (const member of requiredPermissionsOf(program, operation)) {
          const scalar = permissionScalarOf(program, member);
          if (scalar !== undefined) {
            scalars.add(fullName(scalar));
          }
        }
      },
    });

    if (scalars.size > 1) {
      const [first, second] = [...scalars];
      reportDiagnostic(program, {
        code: "permissions-of-two-types",
        format: { service: getNamespaceFullName(service.type), first, second },
        target: service.type,
      });
      one = false;
    }
  }

  return one;
}

/**
 * OAuth2 and OpenID Connect scopes in a @useAuth: the generated endpoints require a signed-in user and check no scope,
 * while the OpenAPI document lists them as required. Reported once per @useAuth.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Service[]} services
 */
function reportUnenforcedScopes(program, services) {
  const checked = new Set();
  /** @param {import("@typespec/compiler").Namespace | import("@typespec/compiler").Interface | import("@typespec/compiler").Operation} type */
  const check = (type) => {
    if (checked.has(type)) {
      return;
    }

    checked.add(type);
    const scopes = new Set(
      getAuthentication(program, type)?.options.flatMap((option) => option.schemes.flatMap(scopesOf)) ?? [],
    );
    if (scopes.size > 0) {
      reportDiagnostic(program, {
        code: "scopes-not-enforced",
        format: { scopes: [...scopes].join(", ") },
        target: type,
      });
    }
  };

  for (const service of services) {
    check(service.type);
    navigateTypesInNamespace(service.type, { namespace: check, interface: check, operation: check });
  }
}

/** @param {import("@typespec/http").HttpAuth} scheme */
function scopesOf(scheme) {
  switch (scheme.type) {
    case "oauth2":
      return scheme.flows.flatMap((flow) => flow.scopes.map((scope) => scope.value));
    case "openIdConnect":
      return scheme.scopes ?? [];
    default:
      return [];
  }
}

/**
 * The parent's code-model writer serializes a compiler Numeric as its isInteger field alone, so every constraint number
 * becomes its exact decimal text first, past 2^53 too. A date or duration bound is dropped instead: its ScalarValue
 * would drag the compiler's syntax tree into tspCodeModel.json, and reportUnsupportedBounds has warned about it.
 * @param {any} model
 */
function normalizeConstraints(model) {
  const constraint = new RegExp(constraintPattern);
  const seen = new Set();
  const pending = [model];
  while (pending.length > 0) {
    const node = pending.pop();
    if (node === null || typeof node !== "object" || seen.has(node)) {
      continue;
    }

    seen.add(node);
    if (Array.isArray(node.decorators)) {
      normalizeDecorators(node.decorators, constraint);
    }

    for (const [key, value] of Object.entries(node)) {
      // __raw and compiler entities lead back into the program, which the writer skips as well
      if (key !== "__raw" && !(value !== null && typeof value === "object" && "entityKind" in value)) {
        pending.push(value);
      }
    }
  }
}

/**
 * In place, since several code-model types may share one array.
 * @param {{ name: string, arguments?: Record<string, unknown> }[]} decorators
 * @param {RegExp} constraint
 */
function normalizeDecorators(decorators, constraint) {
  for (let i = decorators.length - 1; i >= 0; i--) {
    if (!constraint.test(decorators[i].name)) {
      continue;
    }

    const args = decorators[i].arguments ?? {};
    for (const [name, value] of Object.entries(args)) {
      if (isNumeric(value)) {
        args[name] = value.toString();
      } else if (value !== null && typeof value === "object") {
        decorators.splice(i, 1);
        break;
      }
    }
  }
}

/**
 * A date or duration bound has no rule in the generated validators; the spec's author hears about it instead of finding
 * out from a request that passes.
 * @param {import("@typespec/compiler").Program} program
 */
function reportUnsupportedBounds(program) {
  /** @param {import("@typespec/compiler").ModelProperty | import("@typespec/compiler").Scalar} type */
  const check = (type) => {
    for (const decorator of type.decorators) {
      const definition = decorator.definition;
      const value = decorator.args[0]?.jsValue;
      if (
        definition?.namespace !== undefined &&
        getNamespaceFullName(definition.namespace) === "TypeSpec" &&
        valueBounds.includes(definition.name) &&
        value !== null &&
        typeof value === "object" &&
        !isNumeric(value)
      ) {
        reportDiagnostic(program, {
          code: "constraint-not-generated",
          format: { decorator: definition.name },
          target: decorator.node ?? type,
        });
      }
    }
  };

  navigateProgram(program, { modelProperty: check, scalar: check });
}

/**
 * The System.Text.Json generator behind a contracts project's JsonSerializerContext cannot see what Vogen generates in
 * the same compilation, so an id beside its context would serialize as an empty object. Typed ids therefore live in a
 * namespace of their own, written by the primitives project; one inside a service namespace is reported and stops the run.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listTypedIds>} typedIds
 * @param {string[]} services
 */
function typedIdsOutsideServices(program, typedIds, services) {
  let outside = true;
  for (const typedId of typedIds) {
    // The service namespace itself, not the namespaces below it: a primitives spec may well sit at Contoso.Admin.Ids
    if (typedId.namespace.length === 0 || services.includes(typedId.namespace)) {
      reportDiagnostic(program, {
        code: "typed-id-in-service-namespace",
        format: {
          scalar: typedId.name,
          namespace: typedId.namespace.length === 0 ? "the global namespace" : `'${typedId.namespace}'`,
        },
        target: typedId.scalar,
      });
      outside = false;
    }
  }

  return outside;
}

/**
 * The primitives run writes the permission classes as it writes the typed ids, so an @permissions enum inside a service
 * namespace is reported and stops the run, like a typed id there.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listPermissions>} permissions
 * @param {string[]} services
 */
function permissionsOutsideServices(program, permissions, services) {
  let outside = true;
  for (const set of permissions) {
    if (set.namespace.length === 0 || services.includes(set.namespace)) {
      reportDiagnostic(program, {
        code: "permissions-in-service-namespace",
        format: {
          enum: set.name,
          namespace: set.namespace.length === 0 ? "the global namespace" : `'${set.namespace}'`,
        },
        target: set.declaration,
      });
      outside = false;
    }
  }

  return outside;
}

/**
 * The class of a @permissions enum nests a class Names holding the permissions as constants, so no member may be called
 * Names in C#, the first letter upper-cased the way the generator does.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listPermissions>} permissions
 */
function permissionsLeaveNamesFree(program, permissions) {
  let free = true;
  for (const set of permissions) {
    for (const member of set.declaration.members.values()) {
      if (member.name.length > 0 && member.name[0].toUpperCase() + member.name.slice(1) === "Names") {
        reportDiagnostic(program, {
          code: "permission-named-names",
          format: { name: `${set.name}.${member.name}` },
          target: member,
        });
        free = false;
      }
    }
  }

  return free;
}

/**
 * A model or enum lands in the contract namespace of its feature with {feature} in contracts-namespace, and in the one
 * contract namespace without it. Two of one name there would be written to one file, the second over the first.
 * @param {import("@typespec/compiler").Program} program
 * @param {import("@typespec/compiler").Service[]} services
 * @param {unknown} contractsNamespace
 */
function contractNamesDistinct(program, services, contractsNamespace) {
  const byFeature = typeof contractsNamespace === "string" && contractsNamespace.includes("{feature}");
  let distinct = true;
  for (const service of services) {
    const serviceName = getNamespaceFullName(service.type);
    /** @type {Map<string, string>} */
    const declared = new Map();
    const check = (/** @type {import("@typespec/compiler").Model | import("@typespec/compiler").Enum} */ type) => {
      // A feature's permissions may sit below its service, and the primitives run writes them, no contract
      if (
        type.name.length === 0 ||
        (type.kind === "Model" && type.templateMapper !== undefined) ||
        (type.kind === "Enum" && isPermissionSet(program, type))
      ) {
        return;
      }

      const namespace = type.namespace ? getNamespaceFullName(type.namespace) : "";
      const feature = byFeature && namespace.startsWith(`${serviceName}.`) ? namespace.slice(serviceName.length + 1) : "";
      const key = `${feature}/${type.name}`;
      const fullName = `${namespace}.${type.name}`;
      const first = declared.get(key);
      if (first === undefined) {
        declared.set(key, fullName);
        return;
      }

      reportDiagnostic(program, {
        code: "contract-name-twice",
        format: { first, second: fullName, name: type.name },
        target: type,
      });
      distinct = false;
    };

    navigateTypesInNamespace(service.type, { model: check, enum: check }, { includeTemplateDeclaration: false });
  }

  return distinct;
}

/**
 * The class of a @permissions enum as Spec/PermissionSet.cs names it: {Enum}Permissions, in the enum's namespace without
 * a last segment Permissions, which a spec only declares so that a reference reads Permissions.Stations.Read.
 * @param {{ name: string, namespace: string }} set
 */
function permissionClassOf(set) {
  const name = set.name.endsWith("Permissions") ? set.name : `${set.name}Permissions`;
  const namespace = set.namespace.endsWith(".Permissions")
    ? set.namespace.slice(0, -".Permissions".length)
    : set.namespace;
  return { name, namespace, fullName: `${namespace}.${name}` };
}

/**
 * Two enums of one class, the suffix spelled out in one of them or one declared in the namespace the other's class
 * lands in, would declare it twice.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listPermissions>} permissions
 */
function permissionClassesDistinct(program, permissions) {
  /** @type {Map<string, string>} */
  const classes = new Map();
  let distinct = true;
  for (const set of permissions) {
    const fullName = permissionClassOf(set).fullName;
    const enumName = set.namespace.length > 0 ? `${set.namespace}.${set.name}` : set.name;
    const first = classes.get(fullName);
    if (first === undefined) {
      classes.set(fullName, enumName);
      continue;
    }

    reportDiagnostic(program, {
      code: "permission-class-twice",
      format: { first, second: enumName, class: fullName },
      target: set.declaration,
    });
    distinct = false;
  }

  return distinct;
}

/**
 * A permission is named {Enum}.{Member} on the wire and in the database, so two enums of one name on one scalar would
 * name the same permissions, from whatever namespaces.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listPermissions>} permissions
 */
function permissionNamesDistinct(program, permissions) {
  /** @type {Map<string, string>} */
  const declared = new Map();
  let distinct = true;
  for (const set of permissions) {
    const key = `${set.scalar}/${set.name}`;
    const enumName = set.namespace.length > 0 ? `${set.namespace}.${set.name}` : set.name;
    const first = declared.get(key);
    if (first === undefined) {
      declared.set(key, enumName);
      continue;
    }

    reportDiagnostic(program, {
      code: "permission-name-twice",
      format: { first, second: enumName, name: set.name },
      target: set.declaration,
    });
    distinct = false;
  }

  return distinct;
}

/**
 * Two typed ids of one name in two namespaces meet in every generated file that imports both, and the System.Text.Json
 * generator names a contract after its type alone.
 * @param {import("@typespec/compiler").Program} program
 * @param {ReturnType<typeof listTypedIds>} typedIds
 */
function typedIdNamesDistinct(program, typedIds) {
  /** @type {Map<string, string>} */
  const declared = new Map();
  let distinct = true;
  for (const typedId of typedIds) {
    const typedIdName = typedId.namespace.length > 0 ? `${typedId.namespace}.${typedId.name}` : typedId.name;
    const first = declared.get(typedId.name);
    if (first === undefined) {
      declared.set(typedId.name, typedIdName);
      continue;
    }

    reportDiagnostic(program, {
      code: "typed-id-name-twice",
      format: { first, second: typedIdName, name: typedId.name },
      target: typedId.scalar,
    });
    distinct = false;
  }

  return distinct;
}
