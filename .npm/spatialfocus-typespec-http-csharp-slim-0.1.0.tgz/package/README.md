# typespec-http-csharp-slim

TypeSpec emitter for ASP.NET Core. **Server and client from one spec**: minimal API endpoints dispatching to
[Mediator](https://github.com/martinothamar/Mediator) handlers, wire-contract records, result unions (errors as values,
C# 15), and a typed `HttpClient` wrapper for first-party consumers. No System.ClientModel, no controllers.

Built as a plugin for [`@typespec/http-client-csharp`](https://github.com/microsoft/typespec/tree/main/packages/http-client-csharp)
(alpha): its TypeScript half produces the code model, our .NET plugin writes the C#.

## Status

Pre-release. The generator is extracted from a working template and gains a hello-world sample and a
[Spector](https://github.com/microsoft/typespec/tree/main/packages/spector) scenario suite next. Getting-started follows
with the sample.

See [docs/usage.md](docs/usage.md) for what it generates, the emitter options and the contract it expects, and
[AGENTS.md](AGENTS.md) for the layout of this repository, its rules and the development loop.
