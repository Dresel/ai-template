# typespec-http-csharp-slim

TypeSpec emitter for ASP.NET Core. **Server and client from one spec**: minimal API endpoints dispatching to
[Mediator](https://github.com/martinothamar/Mediator) handlers, wire-contract records, result unions (errors as values,
C# 15), and a typed `HttpClient` wrapper for first-party consumers. No System.ClientModel, no controllers.

Built as a plugin for [`@typespec/http-client-csharp`](https://github.com/microsoft/typespec/tree/main/packages/http-client-csharp)
(alpha): its TypeScript half produces the code model, our .NET plugin writes the C#.

## Typed ids and permissions

`@typedId` scalars become Vogen value objects and `@permissions` enums permission classes, written by
`output-type: primitives` into a project of their own, which the contracts that use them reference.

- **One project for all of them**: leave `primitives-namespace` unset. The run writes the whole program, which then
  declares its ids and permission classes in one namespace, and gives the permission scalar `All`, every permission.
- **A project per feature**: each primitives project sets `primitives-namespace` to the namespace it writes. A
  feature's spec imports the spine's for the permission scalar, and its run writes only the feature's ids and
  permission class. The scalar then has no `All`: the product's project, whose spec imports the spine and the features
  the product includes, sets `permission-list: <ClassName>` and gets a class whose `All` lists their permissions.
- A permission class lands in its enum's namespace without a last segment `Permissions`:
  `Contoso.Weather.Primitives.Permissions.Weather` becomes `Contoso.Weather.Primitives.WeatherPermissions`.

## Status

Pre-release. The generator is extracted from a working template and gains a hello-world sample and a
[Spector](https://github.com/microsoft/typespec/tree/main/packages/spector) scenario suite next. Getting-started follows
with the sample.

See [AGENTS.md](AGENTS.md) for the layout of this repository, its rules and the development loop.
